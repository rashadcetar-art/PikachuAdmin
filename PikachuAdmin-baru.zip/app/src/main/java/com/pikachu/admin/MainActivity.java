
package com.pikachu.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.widget.EditText;
import android.widget.Toast;
import android.text.InputType;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private static final String ADMIN_URL =
            "https://pikachuadmin.vercel.app/";

    private static final String FUNCTION_URL =
            "https://wzkjxuenganioqhkdwcq.supabase.co/functions/v1/register-device";

    private static final String SUPABASE_KEY =
            "sb_publishable_Z4RFicXo5xqQMnhcYO01NA_oi1CudH-";

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl(ADMIN_URL);

        if (savedInstanceState == null) {
            askRegistrationCode();
        }
    }

    private void askRegistrationCode() {
        EditText input = new EditText(this);
        input.setHint("Masukkan kode pendaftaran");
        input.setInputType(
                InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        new AlertDialog.Builder(this)
                .setTitle("Pendaftaran Perangkat")
                .setMessage("Masukkan kode pendaftaran perangkat.")
                .setView(input)
                .setCancelable(false)
                .setPositiveButton("Daftar", (dialog, which) -> {
                    String code = input.getText().toString().trim();

                    if (code.isEmpty()) {
                        Toast.makeText(this,
                                "Kode belum diisi",
                                Toast.LENGTH_LONG).show();
                        askRegistrationCode();
                    } else {
                        registerDevice(code);
                    }
                })
                .setNegativeButton("Nanti", (dialog, which) -> {
                    Toast.makeText(this,
                            "Perangkat belum didaftarkan",
                            Toast.LENGTH_LONG).show();
                })
                .show();
    }

    private void registerDevice(String code) {
        String deviceId = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ANDROID_ID
        );

        new Thread(() -> {
            HttpURLConnection connection = null;

            try {
                JSONObject body = new JSONObject();
                body.put("device_id", deviceId);
                body.put("owner", "Android");

                URL url = new URL(FUNCTION_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.setDoOutput(true);
                connection.setRequestProperty(
                        "Content-Type", "application/json"
                );
                connection.setRequestProperty(
                        "apikey", SUPABASE_KEY
                );
                connection.setRequestProperty(
                        "x-registration-code", code
                );

                try (OutputStream output =
                        connection.getOutputStream()) {
                    output.write(body.toString().getBytes("UTF-8"));
                }

                int responseCode = connection.getResponseCode();

                InputStream stream = responseCode >= 200 &&
                        responseCode < 300
                        ? connection.getInputStream()
                        : connection.getErrorStream();

                StringBuilder response = new StringBuilder();

                if (stream != null) {
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(stream, "UTF-8")
                    );

                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                }

                String result = response.toString();

                runOnUiThread(() -> {
                    if (responseCode >= 200 && responseCode < 300) {
                        Toast.makeText(this,
                                "Pendaftaran berhasil. Menunggu persetujuan admin.",
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this,
                                "Pendaftaran gagal: " + result,
                                Toast.LENGTH_LONG).show();
                    }
                });

            } catch (Exception e) {
                runOnUiThread(() ->
                        Toast.makeText(this,
                                "Gagal terhubung: " + e.getMessage(),
                                Toast.LENGTH_LONG).show()
                );
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
